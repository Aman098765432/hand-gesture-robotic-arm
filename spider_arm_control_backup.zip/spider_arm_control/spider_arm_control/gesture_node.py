import rclpy
from rclpy.node import Node
from std_msgs.msg import Float64MultiArray
import cv2
import mediapipe as mp
from mediapipe.python.solutions import hands as mp_hands
from mediapipe.python.solutions import drawing_utils as mp_draw

class GestureArmControl(Node):
    def __init__(self):
        super().__init__('gesture_arm_control')
        self.publisher_ = self.create_publisher(Float64MultiArray, '/arm_controller/commands', 10)
        self.hands = mp_hands.Hands(max_num_hands=1, min_detection_confidence=0.7)
        self.cap = cv2.VideoCapture(0)
        self.timer = self.create_timer(0.05, self.process_frame)
        self.get_logger().info("Hand Gesture Node Started!")

    def process_frame(self):
        ret, frame = self.cap.read()
        if not ret:
            return
        frame = cv2.flip(frame, 1)
        rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        results = self.hands.process(rgb_frame)

        waist_angle, shoulder_angle, elbow_angle, gripper_pos = 0.0, 0.2, 0.5, 0.0

        if results.multi_hand_landmarks:
            for hand_landmarks in results.multi_hand_landmarks:
                mp_draw.draw_landmarks(frame, hand_landmarks, mp_hands.HAND_CONNECTIONS)
                index_tip = hand_landmarks.landmark[mp_hands.HandLandmark.INDEX_FINGER_TIP]
                thumb_tip = hand_landmarks.landmark[mp_hands.HandLandmark.THUMB_TIP]

                waist_angle = (index_tip.x - 0.5) * -3.0
                shoulder_angle = (index_tip.y - 0.5) * 2.0

                distance = ((index_tip.x - thumb_tip.x)**2 + (index_tip.y - thumb_tip.y)**2)**0.5
                gripper_pos = 0.0 if distance < 0.08 else 0.04

        msg = Float64MultiArray()
        msg.data = [waist_angle, shoulder_angle, elbow_angle, gripper_pos]
        self.publisher_.publish(msg)
        cv2.imshow("Hand Gesture Controller", frame)
        cv2.waitKey(1)

def main(args=None):
    rclpy.init(args=args)
    node = GestureArmControl()
    rclpy.spin(node)
    node.cap.release()
    cv2.destroyAllWindows()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
