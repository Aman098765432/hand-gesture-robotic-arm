import rclpy
from rclpy.node import Node
from std_msgs.msg import Float64MultiArray
import tkinter as tk
from threading import Thread

class ArmGuiControl(Node):
    def __init__(self):
        super().__init__('gui_arm_control')
        self.publisher_ = self.create_publisher(Float64MultiArray, '/arm_controller/commands', 10)
        self.waist = 0.0
        self.shoulder = 0.0
        self.elbow = 0.5
        self.wrist = 0.0
        self.g_left = 0.0
        self.g_right = 0.0

    def publish_joints(self):
        msg = Float64MultiArray()
        msg.data = [self.waist, self.shoulder, self.elbow, self.wrist, self.g_left, self.g_right]
        self.publisher_.publish(msg)

def launch_gui(node):
    root = tk.Tk()
    root.title("SpiderPi Arm GUI Controller")
    root.geometry("450x560")

    def make_slider(label, f, t, init, cb):
        tk.Label(root, text=label, font=('Arial', 10, 'bold')).pack(pady=3)
        s = tk.Scale(root, from_=f, to=t, resolution=0.02, orient=tk.HORIZONTAL, command=cb, length=350)
        s.set(init)
        s.pack()
        return s

    s_w = make_slider("Base / Waist (Left / Right)", -3.14, 3.14, 0.0, lambda v: setattr(node, 'waist', float(v)) or node.publish_joints())
    s_s = make_slider("Shoulder Joint (Up / Down)", -1.57, 1.57, 0.0, lambda v: setattr(node, 'shoulder', float(v)) or node.publish_joints())
    s_e = make_slider("Elbow Joint (Bend Arm)", -2.0, 2.0, 0.5, lambda v: setattr(node, 'elbow', float(v)) or node.publish_joints())
    s_wr = make_slider("Wrist Pitch Joint", -1.57, 1.57, 0.0, lambda v: setattr(node, 'wrist', float(v)) or node.publish_joints())

    tk.Label(root, text="Gripper Controls", font=('Arial', 10, 'bold')).pack(pady=8)
    fg = tk.Frame(root)
    fg.pack()

    def open_g():
        node.g_left, node.g_right = 0.0, 0.0
        node.publish_joints()

    def close_g():
        node.g_left, node.g_right = -0.02, 0.02
        node.publish_joints()

    tk.Button(fg, text="OPEN Gripper", bg="lightgreen", width=14, font=('Arial', 9, 'bold'), command=open_g).pack(side=tk.LEFT, padx=5)
    tk.Button(fg, text="CLOSE (Grasp)", bg="pink", width=14, font=('Arial', 9, 'bold'), command=close_g).pack(side=tk.RIGHT, padx=5)

    tk.Label(root, text="Quick Actions", font=('Arial', 10, 'bold')).pack(pady=8)
    fp = tk.Frame(root)
    fp.pack()

    def pick_pos():
        # Angles adjusted perfectly for x=0.18m cube position
        s_w.set(0.0)
        s_s.set(0.32)
        s_e.set(1.05)
        s_wr.set(-0.85)
        open_g()

    def home_pos():
        s_w.set(0.0)
        s_s.set(0.0)
        s_e.set(0.5)
        s_wr.set(0.0)
        open_g()

    tk.Button(fp, text="Pick Position", width=14, command=pick_pos).pack(side=tk.LEFT, padx=5)
    tk.Button(fp, text="Home Position", width=14, command=home_pos).pack(side=tk.RIGHT, padx=5)

    root.mainloop()

def main(args=None):
    rclpy.init(args=args)
    node = ArmGuiControl()
    Thread(target=rclpy.spin, args=(node,), daemon=True).start()
    launch_gui(node)
    rclpy.shutdown()

if __name__ == '__main__':
    main()
