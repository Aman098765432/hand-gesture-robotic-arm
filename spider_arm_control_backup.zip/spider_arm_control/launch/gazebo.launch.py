import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import ExecuteProcess, RegisterEventHandler
from launch.event_handlers import OnProcessExit
from launch_ros.actions import Node

def generate_launch_description():
    pkg_path = get_package_share_directory('spider_arm_control')
    xacro_file = os.path.join(pkg_path, 'urdf', 'spider_arm.urdf.xacro')
    controllers_yaml = os.path.join(pkg_path, 'config', 'controllers.yaml')

    with open(xacro_file, 'r') as f:
        robot_desc_content = f.read()
    robot_desc_content = robot_desc_content.replace('CONTROLLERS_YAML_PATH', controllers_yaml)
    
    robot_description = {'robot_description': robot_desc_content}

    world_sdf = """
    <?xml version="1.0" ?>
    <sdf version="1.8">
      <world name="default">
        <plugin filename="gz-sim-physics-system" name="gz::sim::systems::Physics"/>
        <plugin filename="gz-sim-user-commands-system" name="gz::sim::systems::UserCommands"/>
        <plugin filename="gz-sim-scene-broadcaster-system" name="gz::sim::systems::SceneBroadcaster"/>
        
        <light type="directional" name="sun">
          <cast_shadows>true</cast_shadows>
          <pose>0 0 10 0 0 0</pose>
          <diffuse>1 1 1 1</diffuse>
        </light>
        
        <model name="ground_plane">
          <static>true</static>
          <link name="link">
            <collision name="collision"><geometry><plane><normal>0 0 1</normal><size>100 100</size></plane></geometry></collision>
            <visual name="visual"><geometry><plane><normal>0 0 1</normal><size>100 100</size></plane></geometry><material><ambient>0.8 0.8 0.8 1</ambient><diffuse>0.8 0.8 0.8 1</diffuse></material></visual>
          </link>
        </model>
        
        <!-- Cube placed closer at x=0.18m for easy reach -->
        <model name="red_cube">
          <pose>0.18 0 0.025 0 0 0</pose>
          <link name="link">
            <inertial><mass>0.02</mass><inertia><ixx>0.00001</ixx><ixy>0</ixy><ixz>0</ixz><iyy>0.00001</iyy><iyz>0</iyz><izz>0.00001</izz></inertia></inertial>
            <visual name="visual"><geometry><box><size>0.04 0.04 0.04</size></box></geometry><material><ambient>1 0 0 1</ambient><diffuse>1 0 0 1</diffuse></material></visual>
            <collision name="collision"><geometry><box><size>0.04 0.04 0.04</size></box></geometry></collision>
          </link>
        </model>
      </world>
    </sdf>
    """

    world_path = '/tmp/spider_world.sdf'
    with open(world_path, 'w') as f:
        f.write(world_sdf)

    spawn_robot = Node(
        package='ros_gz_sim',
        executable='create',
        arguments=['-string', robot_desc_content, '-name', 'spider_arm', '-x', '0', '-y', '0', '-z', '0'],
        output='screen'
    )

    jsb_spawner = Node(
        package='controller_manager',
        executable='spawner',
        arguments=['joint_state_broadcaster'],
        output='screen'
    )

    arm_spawner = Node(
        package='controller_manager',
        executable='spawner',
        arguments=['arm_controller'],
        output='screen'
    )

    return LaunchDescription([
        ExecuteProcess(cmd=['gz', 'sim', '-r', world_path], output='screen'),
        Node(package='robot_state_publisher', executable='robot_state_publisher', output='screen', parameters=[robot_description]),
        spawn_robot,
        Node(package='ros_gz_bridge', executable='parameter_bridge', arguments=['/clock@rosgraph_msgs/msg/Clock[gz.msgs.Clock'], output='screen'),
        RegisterEventHandler(event_handler=OnProcessExit(target_action=spawn_robot, on_exit=[jsb_spawner])),
        RegisterEventHandler(event_handler=OnProcessExit(target_action=jsb_spawner, on_exit=[arm_spawner]))
    ])
